**Start Simple Bootstrap 4 Template**
v1.0.0
Release Date: 26th Sept, 2017

A simple one page template for Startups and Small Business built with Bootstrap 4


Live Demo - https://templateflip.com/demo/?template=start-simple
Download - https://templateflip.com/templates/start-simple/

You may also want to check out other Website templates - https://templateflip.com/templates/

License

Licensed under the Creative Commons Attribution 3.0 license.
You can use this template for free in both personal as well as commercial projects. 
In return, just credit https://templateflip.com for the website template on your site. 
You can do this by leaving the footer credit "Design: TemplateFlip" intact on your site.
